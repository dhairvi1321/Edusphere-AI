from django.contrib.auth.models import User
from rest_framework import serializers

from edusphere.serializers import MongoModelSerializer

class RegisterSerializer(MongoModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)

    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password', 'first_name')

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)
