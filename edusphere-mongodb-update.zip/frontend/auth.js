// Backend base URL. To point at another server, define this BEFORE loading auth.js:
//   <script>window.EDUSPHERE_API = 'https://your-backend.example.com/api';</script>
const API = window.EDUSPHERE_API || 'http://127.0.0.1:8000/api';
const SESSION_KEY = 'edusphere_session';

const Auth = {
  getSession() {
    const s = localStorage.getItem(SESSION_KEY) || sessionStorage.getItem(SESSION_KEY);
    return s ? JSON.parse(s) : null;
  },

  saveSession(data, remember = true) {
    const store = remember ? localStorage : sessionStorage;
    store.setItem(SESSION_KEY, JSON.stringify(data));
  },

  getToken() {
    return this.getSession()?.access || null;
  },

  async register(name, email, password) {
    try {
      const res = await fetch(`${API}/auth/register/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: email, email, password, first_name: name })
      });
      const data = await res.json();
      if (!res.ok) {
        const msg = data.username?.[0] || data.email?.[0] || data.password?.[0] || data.detail || 'Registration failed.';
        return { ok: false, error: msg };
      }
      return { ok: true };
    } catch {
      return { ok: false, error: 'Cannot connect to server. Make sure the backend is running.' };
    }
  },

  async login(email, password, remember = true) {
    try {
      const res = await fetch(`${API}/auth/login/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        return { ok: false, error: data.detail || 'Invalid email or password.' };
      }
      return await this._finalizeLogin(data, email, remember);
    } catch {
      return { ok: false, error: 'Cannot connect to server. Make sure the backend is running.' };
    }
  },

  async googleLogin(credential, remember = true) {
    try {
      const res = await fetch(`${API}/auth/google/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ credential })
      });
      const data = await res.json();
      if (!res.ok) {
        return { ok: false, error: data.detail || 'Google login failed.' };
      }
      return await this._finalizeLogin(data, null, remember);
    } catch {
      return { ok: false, error: 'Cannot connect to server. Make sure the backend is running.' };
    }
  },

  async _finalizeLogin(tokenData, emailFallback, remember) {
    let name = emailFallback ? emailFallback.split('@')[0] : 'Student';
    let email = emailFallback || '';
    try {
      const meRes = await fetch(`${API}/auth/me/`, {
        headers: { Authorization: `Bearer ${tokenData.access}` }
      });
      if (meRes.ok) {
        const me = await meRes.json();
        name = me.name || name;
        email = me.email || email;
      }
    } catch { /* use fallback */ }

    const session = { access: tokenData.access, refresh: tokenData.refresh, email, name };
    this.saveSession(session, remember);
    return { ok: true, user: session };
  },

  logout() {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    window.location.href = 'index.html';
  },

  requireAuth() {
    if (!this.getSession()) window.location.href = 'login.html';
  },

  _storage() {
    if (localStorage.getItem(SESSION_KEY)) return localStorage;
    if (sessionStorage.getItem(SESSION_KEY)) return sessionStorage;
    return null;
  },

  // Exchange the refresh token for a new access token (access tokens last 1 day).
  async _refreshAccess() {
    const session = this.getSession();
    if (!session?.refresh) return false;
    try {
      const res = await fetch(`${API}/auth/token/refresh/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh: session.refresh })
      });
      if (!res.ok) return false;
      const data = await res.json();
      session.access = data.access;
      if (data.refresh) session.refresh = data.refresh;
      this._storage()?.setItem(SESSION_KEY, JSON.stringify(session));
      return true;
    } catch {
      return false;
    }
  },

  /**
   * Authenticated request to the API. `path` is relative to API (e.g. '/academics/subjects/').
   * Returns parsed JSON on success, `true` for empty (204) responses such as DELETE,
   * and `null` on any error (network down, validation error, 404, ...).
   * A 401 triggers one silent token refresh; if that fails the user is logged out.
   */
  async apiFetch(path, options = {}, _retried = false) {
    let res;
    try {
      res = await fetch(`${API}${path}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...(this.getToken() ? { Authorization: `Bearer ${this.getToken()}` } : {}),
          ...(options.headers || {})
        }
      });
    } catch {
      return null; // backend unreachable
    }

    if (res.status === 401) {
      if (!_retried && await this._refreshAccess()) return this.apiFetch(path, options, true);
      this.logout();
      return null;
    }
    if (!res.ok) return null;
    if (res.status === 204) return true;
    return res.json();
  }
};
