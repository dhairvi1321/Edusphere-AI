"""
DRF glue for MongoDB ObjectId primary keys.

Out of the box DRF treats ObjectIdAutoField as an integer, which breaks JSON
output. These classes represent ObjectIds as 24-character hex strings in the
API (e.g. "66f1c0a2b7d3a45e8c9e1f20") and accept the same strings as input.
"""
from django.core.exceptions import ValidationError as DjangoValidationError
from django_mongodb_backend.fields import ObjectIdAutoField, ObjectIdField
from rest_framework import serializers


class ObjectIdStringField(serializers.CharField):
    def to_representation(self, value):
        return str(value)


class ObjectIdRelatedField(serializers.PrimaryKeyRelatedField):
    """Foreign keys are read/written as ObjectId hex strings."""

    def to_representation(self, value):
        return str(value.pk)

    def to_internal_value(self, data):
        try:
            return super().to_internal_value(data)
        except DjangoValidationError:  # malformed id such as "abc"
            self.fail('incorrect_type', data_type=type(data).__name__)


class MongoModelSerializer(serializers.ModelSerializer):
    serializer_field_mapping = {
        **serializers.ModelSerializer.serializer_field_mapping,
        ObjectIdAutoField: ObjectIdStringField,
        ObjectIdField: ObjectIdStringField,
    }
    serializer_related_field = ObjectIdRelatedField
