from rest_framework import serializers
from edusphere.serializers import MongoModelSerializer
from .models import Subject, SyllabusTopic, Assignment, Exam


class OwnedSubjectMixin:
    """A subject referenced in a request body must belong to the logged-in user."""

    def validate_subject(self, subject):
        request = self.context.get('request')
        if subject is not None and request and subject.user_id != request.user.id:
            raise serializers.ValidationError('Subject not found.')
        return subject


class SyllabusTopicSerializer(OwnedSubjectMixin, MongoModelSerializer):
    class Meta:
        model = SyllabusTopic
        fields = ('id', 'subject', 'title', 'is_completed')


class SubjectSerializer(MongoModelSerializer):
    topics = SyllabusTopicSerializer(many=True, read_only=True)

    class Meta:
        model = Subject
        fields = ('id', 'name', 'description', 'topics', 'created_at')
        read_only_fields = ('created_at',)


class AssignmentSerializer(OwnedSubjectMixin, MongoModelSerializer):
    class Meta:
        model = Assignment
        fields = ('id', 'subject', 'title', 'due_date', 'priority', 'is_completed')


class ExamSerializer(OwnedSubjectMixin, MongoModelSerializer):
    class Meta:
        model = Exam
        fields = ('id', 'subject', 'title', 'exam_date', 'notes')
